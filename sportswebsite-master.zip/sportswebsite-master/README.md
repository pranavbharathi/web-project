# Nairobi Sports Training Guide

## SPECS
We aim to create a sports training guide website for a Nairobian. It will have information
that is useful pertaining to:
> 1. Training guide
> 2. Exercise routine
> 3. Training routes
> 4. Events calendar
> 5. Training facilities
> 6. Daily weather update
> 7. Dietary information
> 8. somethin

This will be done through creation of webpages. I propose the following pages:
> 1. Home page
> > * With daily weather update
> > * Footer (social, )
> 2. Dietary guide page
> 3. Routes and facility guide page.equipment and gear nguo
> 4. Exercise routine guide for each type of sport.
> 5.

Contributors
> 1. Victor Ngeno
> 2. Elvis Mogaka
> 3. Dave Adeola
> 4. Sam
> 5. Miriam Njeri
