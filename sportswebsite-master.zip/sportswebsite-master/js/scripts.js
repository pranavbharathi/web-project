//USER LOGIC
var myVar;

function myFunction() {
    myVar = setTimeout(showPage, 4000);
}

function showPage() {
    document.getElementById("loader").style.display = "none";
    document.getElementById("main").style.display = "block";
    document.getElementById("navimage1").style.display = "block";
}







function openNav() {
    document.getElementById("mySidenav").style.width = "300px";
    $("div#main").css("opacity", "0.5");
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    $("div#main").css("opacity", "1");
}

function getWeatherData(locatedUser) {
    $.ajax({
        url: 'http://api.openweathermap.org/data/2.5/weather?q=Delhi&APPID=b08c17796dfca60b0a62f15dadf24364',
        success: function(data) {
            var today = new Date();
            var weekday = new Array(7);
            weekday[0] = "Sunday";
            weekday[1] = "Monday";
            weekday[2] = "Tuesday";
            weekday[3] = "Wednesday";
            weekday[4] = "Thursday";
            weekday[5] = "Friday";
            weekday[6] = "Saturday";
            $("div.content#weather").text("");
            $("div.content#weather").append("<div>" +
                "<h2>" + data.name + "," + data.sys.country + "</h2>" +
                "<h3>" + weekday[today.getDay()] + "," + today.getDate() + "/" + (today.getMonth() + 1) + "/" + today.getFullYear() + "</h3>" +
                "<h3>" + data.weather[0].description + "</h3>" +
                "<img src='http://openweathermap.org/img/w/" + data.weather[0].icon + ".png' alt='weather-icon'></img>" +
                "</div>");

        },
        error: function(err) {
            console.log(err);
        }

    });
}


$(document).ready(function() {

    getWeatherData();
});
var hater = {
    "coord": {
        "lon": 77.22,
        "lat": 28.67
    },
    "weather": [{
        "id": 721,
        "main": "Haze",
        "description": "haze",
        "icon": "50n"
    }],
    "base": "stations",
    "main": {
        "temp": 285.86,
        "feels_like": 283.5,
        "temp_min": 283.15,
        "temp_max": 288.71,
        "pressure": 1019,
        "humidity": 71
    },
    "visibility": 2500,
    "wind": {
        "speed": 2.57,
        "deg": 302
    },
    "clouds": {
        "all": 0
    },
    "dt": 1608313643,
    "sys": {
        "type": 1,
        "id": 9165,
        "country": "IN",
        "sunrise": 1608255499,
        "sunset": 1608292639
    },
    "timezone": 19800,
    "id": 1273294,
    "name": "Delhi",
    "cod": 200
};